# VANN ISLAND v8

Pembaruan:
- Ikon aplikasi VANN ISLAND.
- Animasi masuk Control Center saat aplikasi dibuka.
- Kapsul idle tetap kecil dan kosong, menyatu dengan area kamera.
- Saat notifikasi masuk, kapsul melebar dengan animasi dan kembali ke idle setelah 4,5 detik.
- Service tidak berhenti saat tidak ada notifikasi. Tekan STOP untuk menghentikan sepenuhnya.

Build menggunakan workflow GitHub Actions yang sama. Ubah nama ZIP pada perintah unzip menjadi `VANN_ISLAND_v8_source.zip`.


VANN ISLAND v9: posisi awal overlay disetel ke 30dp dari bagian atas layar agar lebih dekat dan sejajar dengan kamera depan Redmi 13C. Atur lebih lanjut melalui slider Posisi dari atas (dp).


VANN ISLAND v10 visual refresh: larger rounded expanded capsule, app icon or media album art, improved typography, animated media indicator, and smoother expand/collapse transitions. Notification preview auto-collapses to the camera-aligned idle pill; foreground service remains active until Stop.
