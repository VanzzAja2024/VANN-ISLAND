plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vann.island"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vann.island"
        minSdk = 26
        targetSdk = 32
        versionCode = 10
        versionName = "10.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
