package com.vann.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.animation.ValueAnimator
import android.animation.ObjectAnimator
import android.animation.AnimatorSet
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ImageView

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var camera: CameraManager
    private var cameraId: String? = null
    private var root: LinearLayout? = null
    private var iconView: ImageView? = null
    private var titleView: TextView? = null
    private var bodyView: TextView? = null
    private var trailingView: TextView? = null
    private var flashView: TextView? = null
    private var currentPackage = ""
    private var currentSource = ""
    private var currentTitle = "VANN ISLAND"
    private var currentBody = ""
    private var currentCover: Bitmap? = null
    private var expanded = false
    private var testMode = false
    private var animator: ValueAnimator? = null
    private var equalizer: AnimatorSet? = null
    private val handler = Handler(Looper.getMainLooper())
    private val collapseTask = Runnable { collapseToIdle() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.vann.island.MEDIA_UPDATE" -> {
                    if (testMode) return
                    currentTitle = intent.getStringExtra("title") ?: "Notifikasi"
                    currentBody = intent.getStringExtra("body") ?: ""
                    currentPackage = intent.getStringExtra("source_package") ?: ""
                    currentSource = intent.getStringExtra("source") ?: ""
                    currentCover = readCover(intent)
                    renderContent()
                    showExpandedTemporarily()
                }
                "com.vann.island.NOTIFICATION_CLEARED" -> { }
                "com.vann.island.UPDATE_SETTINGS" -> updateLayout()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = Notification.Builder(this, "vann_running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("VANN ISLAND aktif")
            .setContentText("Dynamic Island sedang berjalan")
            .setOngoing(true).build()
        startForeground(501, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        camera = getSystemService(CAMERA_SERVICE) as CameraManager
        try {
            cameraId = camera.cameraIdList.firstOrNull {
                camera.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) { }
        val filter = IntentFilter().apply {
            addAction("com.vann.island.MEDIA_UPDATE")
            addAction("com.vann.island.NOTIFICATION_CLEARED")
            addAction("com.vann.island.UPDATE_SETTINGS")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
        createIsland()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        testMode = intent?.getBooleanExtra("test_mode", false) ?: false
        if (testMode) {
            currentSource = "media"
            currentPackage = ""
            currentCover = null
            currentTitle = "Now Playing"
            currentBody = "VANN ISLAND Preview"
            renderContent()
            showExpandedTemporarily()
        } else collapseToIdle()
        return START_STICKY
    }

    private fun capsuleBackground(expanded: Boolean) = GradientDrawable().apply {
        setColor(Color.BLACK)
        cornerRadius = if (expanded) 34.dp().toFloat() else 40.dp().toFloat()
        setStroke(1.dp(), 0xFF202126.toInt())
    }

    private fun createIsland() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(15.dp(), 7.dp(), 15.dp(), 7.dp())
            background = capsuleBackground(false)
            elevation = 18.dp().toFloat()
            alpha = 1f
        }

        iconView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { cornerRadius = 9.dp().toFloat(); setColor(0xFF202126.toInt()) }
            clipToOutline = true
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleView = TextView(this).apply {
            textSize = 12.5f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        bodyView = TextView(this).apply {
            textSize = 10.5f
            setTextColor(0xFFB8BBC4.toInt())
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        texts.addView(titleView)
        texts.addView(bodyView)

        trailingView = TextView(this).apply {
            text = "•••"
            textSize = 12f
            setTextColor(0xFFB8BBC4.toInt())
            gravity = Gravity.CENTER
            setPadding(8.dp(), 0, 0, 0)
        }
        flashView = TextView(this).apply {
            text = "⚡"
            textSize = 16f
            setTextColor(0xFFFFD45A.toInt())
            gravity = Gravity.CENTER
            setPadding(8.dp(), 0, 0, 0)
            setOnClickListener { toggleFlash() }
        }

        root?.addView(iconView, LinearLayout.LayoutParams(32.dp(), 32.dp()).apply { rightMargin = 10.dp() })
        root?.addView(texts, LinearLayout.LayoutParams(0, -1, 1f))
        root?.addView(trailingView, LinearLayout.LayoutParams(28.dp(), 34.dp()))
        root?.addView(flashView, LinearLayout.LayoutParams(28.dp(), 34.dp()))
        root?.setOnClickListener {
            if (expanded) collapseToIdle() else showExpandedTemporarily()
        }

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            idleWidth().dp(), idleHeight().dp(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = topOffset().dp()
        try { wm.addView(root, params) } catch (_: Exception) { }
        renderContent()
        setIdleVisibility()
    }

    @Suppress("DEPRECATION")
    private fun readCover(intent: Intent): Bitmap? {
        return if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("cover", Bitmap::class.java)
        else intent.getParcelableExtra("cover")
    }

    private fun idleWidth() = 116
    private fun idleHeight() = 36
    private fun topOffset(): Int =
        getSharedPreferences("vann_settings", MODE_PRIVATE).getInt("position", 30).coerceIn(0, 80)

    private fun renderContent() {
        titleView?.text = currentTitle
        bodyView?.text = currentBody
        val icon = iconView ?: return
        if (currentCover != null && currentSource == "media") {
            icon.setImageBitmap(currentCover)
        } else if (currentPackage.isNotBlank()) {
            try { icon.setImageDrawable(packageManager.getApplicationIcon(currentPackage)) }
            catch (_: Exception) { icon.setImageResource(android.R.drawable.ic_dialog_info) }
        } else {
            icon.setImageResource(android.R.drawable.ic_media_play)
        }
        trailingView?.text = if (currentSource == "media") "♫" else "•••"
        trailingView?.setTextColor(if (currentSource == "media") 0xFF35D66F.toInt() else 0xFFB8BBC4.toInt())
    }

    private fun setIdleVisibility() {
        val visible = if (expanded) View.VISIBLE else View.GONE
        iconView?.visibility = visible
        titleView?.visibility = visible
        bodyView?.visibility = visible
        trailingView?.visibility = visible
        flashView?.visibility = visible
        root?.background = capsuleBackground(expanded)
        if (expanded && currentSource == "media") startEqualizer() else stopEqualizer()
    }

    private fun startEqualizer() {
        stopEqualizer()
        val v = trailingView ?: return
        val a = ObjectAnimator.ofFloat(v, View.SCALE_Y, 0.55f, 1.2f, 0.7f).apply {
            duration = 620
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }
        val b = ObjectAnimator.ofFloat(v, View.ALPHA, 0.65f, 1f).apply {
            duration = 480
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }
        equalizer = AnimatorSet().apply { playTogether(a, b); start() }
    }

    private fun stopEqualizer() {
        equalizer?.cancel()
        equalizer = null
        trailingView?.scaleY = 1f
        trailingView?.alpha = 1f
    }

    private fun showExpandedTemporarily() {
        handler.removeCallbacks(collapseTask)
        expanded = true
        setIdleVisibility()
        root?.background = capsuleBackground(true)
        val prefs = getSharedPreferences("vann_settings", MODE_PRIVATE)
        val w = (prefs.getInt("width", 300) + 20).coerceIn(250, 370)
        val h = (prefs.getInt("height", 58) + 18).coerceIn(58, 100)
        animateSize(w, h)
        root?.animate()?.alpha(1f)?.scaleX(1f)?.scaleY(1f)?.setDuration(360)
            ?.setInterpolator(DecelerateInterpolator())?.start()
        handler.postDelayed(collapseTask, if (currentSource == "media") 6500 else 4500)
    }

    private fun collapseToIdle() {
        handler.removeCallbacks(collapseTask)
        expanded = false
        setIdleVisibility()
        animateSize(idleWidth(), idleHeight())
        root?.animate()?.alpha(1f)?.scaleX(1f)?.scaleY(1f)?.setDuration(340)
            ?.setInterpolator(DecelerateInterpolator())?.start()
    }

    private fun animateSize(targetWidth: Int, targetHeight: Int) {
        val view = root ?: return
        val params = view.layoutParams as? WindowManager.LayoutParams ?: return
        animator?.cancel()
        val startW = params.width / resources.displayMetrics.density
        val startH = params.height / resources.displayMetrics.density
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 360
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                params.width = (startW + (targetWidth - startW) * f).toInt().dp()
                params.height = (startH + (targetHeight - startH) * f).toInt().dp()
                try { wm.updateViewLayout(view, params) } catch (_: Exception) { }
            }
            start()
        }
    }

    private fun updateLayout() {
        val view = root ?: return
        val params = view.layoutParams as? WindowManager.LayoutParams ?: return
        params.y = topOffset().dp()
        try { wm.updateViewLayout(view, params) } catch (_: Exception) { }
        if (expanded) showExpandedTemporarily() else collapseToIdle()
    }

    private fun toggleFlash() {
        val id = cameraId ?: return
        try {
            val prefs = getSharedPreferences("vann_settings", MODE_PRIVATE)
            val on = prefs.getBoolean("flash_on", false)
            camera.setTorchMode(id, !on)
            prefs.edit().putBoolean("flash_on", !on).apply()
            flashView?.setTextColor(if (!on) 0xFF27D66B.toInt() else 0xFFFFD45A.toInt())
        } catch (_: Exception) { }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("vann_running", "VANN Island", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        animator?.cancel()
        stopEqualizer()
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        try { root?.let { wm.removeView(it) } } catch (_: Exception) { }
        try { cameraId?.let { camera.setTorchMode(it, false) } } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
}
