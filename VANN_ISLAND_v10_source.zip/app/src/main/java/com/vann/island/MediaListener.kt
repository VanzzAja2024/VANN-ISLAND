package com.vann.island

import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MediaListener : NotificationListenerService() {
    private var manager: MediaSessionManager? = null
    private val controllers = mutableSetOf<MediaController>()
    private var activePackage = ""

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            val art = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            sendUpdate("♫",
                metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sedang diputar",
                metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Musik",
                "media", activePackage, art)
        }

        override fun onPlaybackStateChanged(state: android.media.session.PlaybackState?) {
            val playing = state?.state == android.media.session.PlaybackState.STATE_PLAYING
            if (playing) refreshSessions()
            else sendUpdate("Ⅱ", "Musik dijeda", "Pemutaran dijeda", "media", activePackage)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        refreshSessions()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString()?.takeIf { it.isNotBlank() } ?: return
        val body = extras.getCharSequence("android.bigText")?.toString()
            ?: extras.getCharSequence("android.text")?.toString().orEmpty()
        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName.substringAfterLast('.') }
        sendUpdate("●", title, body, appName, sbn.packageName)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        sendBroadcast(Intent("com.vann.island.NOTIFICATION_CLEARED").setPackage(packageName))
    }

    private fun refreshSessions() {
        try {
            controllers.forEach { it.unregisterCallback(callback) }
            controllers.clear()
            val active = manager?.getActiveSessions(ComponentName(this, MediaListener::class.java)).orEmpty()
            active.forEach { controller ->
                controllers.add(controller)
                activePackage = controller.packageName
                controller.registerCallback(callback)
                val metadata = controller.metadata
                val state = controller.playbackState?.state
                if (metadata != null && state == android.media.session.PlaybackState.STATE_PLAYING) {
                    val art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                        ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                    sendUpdate("♫",
                        metadata.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sedang diputar",
                        metadata.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Musik",
                        "media", controller.packageName, art)
                }
            }
        } catch (_: SecurityException) { }
    }

    private fun sendUpdate(icon: String, title: String, body: String, source: String,
                           sourcePackage: String = "", cover: Bitmap? = null) {
        val intent = Intent("com.vann.island.MEDIA_UPDATE").setPackage(packageName)
            .putExtra("icon", icon).putExtra("title", title).putExtra("body", body)
            .putExtra("source", source).putExtra("source_package", sourcePackage)
        if (cover != null) {
            val scaled = if (cover.width > 160 || cover.height > 160)
                Bitmap.createScaledBitmap(cover, 160, 160, true) else cover
            intent.putExtra("cover", scaled)
        }
        sendBroadcast(intent)
    }
}
