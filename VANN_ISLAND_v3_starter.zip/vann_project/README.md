# VANN ISLAND v3 starter

Android Studio/Gradle project for a manually started overlay prototype. It includes overlay permission settings, start/stop controls, and a notification-listener prototype that reads media-style notification title/text.

Important: this is an early starter build, not a finished iOS-quality Dynamic Island. Reliable playback controls, album art, media-session transport controls, smooth animations, and foreground-service hardening still need implementation and device testing. Notification access can expose notification contents, so enable it only if you accept that permission.

Build: `gradle assembleDebug` with JDK 17 and Android SDK 35.
