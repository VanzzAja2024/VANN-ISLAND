package com.vann.island

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private var pill: TextView? = null
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val title = intent?.getStringExtra("title") ?: "Music"
            val artist = intent?.getStringExtra("artist") ?: "Now Playing"
            pill?.text = "♫  $title\n     $artist"
        }
    }
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val filter = IntentFilter("com.vann.island.MEDIA_UPDATE")
        registerReceiver(receiver, filter)
        pill = TextView(this).apply {
            text = "VANN ISLAND\nTap STOP in app to close"
            setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
            setPadding(34, 18, 34, 18); setBackgroundColor(Color.BLACK)
        }
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; params.y = 24
        wm.addView(pill, params)
    }
    override fun onDestroy() { try { unregisterReceiver(receiver); pill?.let { wm.removeView(it) } } catch (_: Exception) {}; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
