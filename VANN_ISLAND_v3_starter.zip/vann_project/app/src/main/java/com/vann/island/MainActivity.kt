package com.vann.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 60, 36, 36); setBackgroundColor(0xFF080808.toInt()) }
        fun text(s: String, size: Float) = TextView(this).apply { text = s; textSize = size; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 14, 0, 14) }
        root.addView(text("VANN ISLAND", 28f))
        root.addView(text("Dynamic Island untuk Android", 16f))
        root.addView(text("Aktifkan izin overlay dan akses musik/notifikasi agar kapsul dapat menampilkan media yang sedang diputar.", 14f))
        root.addView(Button(this).apply { text = "IZIN TAMPIL DI ATAS APLIKASI"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
        root.addView(Button(this).apply { text = "AKSES NOTIFIKASI & MUSIK"; setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } })
        root.addView(Button(this).apply { text = "START ISLAND"; setOnClickListener { if (Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity, IslandService::class.java)) else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
        root.addView(Button(this).apply { text = "STOP ISLAND"; setOnClickListener { stopService(Intent(this@MainActivity, IslandService::class.java)) } })
        setContentView(root)
    }
}
