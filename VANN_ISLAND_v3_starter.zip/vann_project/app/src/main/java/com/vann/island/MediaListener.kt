package com.vann.island

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.media.session.MediaSession
import android.media.session.MediaController

class MediaListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val artist = extras.getCharSequence("android.text")?.toString() ?: ""
        val intent = android.content.Intent("com.vann.island.MEDIA_UPDATE")
            .putExtra("title", title).putExtra("artist", artist)
        sendBroadcast(intent)
    }
}
