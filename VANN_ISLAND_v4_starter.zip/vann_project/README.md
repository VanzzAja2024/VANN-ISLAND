# VANN ISLAND v4

Android starter project for Redmi 13C / HyperOS.

Features in this build:
- First-launch control center with live preview.
- Width, height, and vertical position sliders saved on device.
- Overlay permission shortcut.
- Notification-listener access shortcut for media metadata.
- Test Mode, Start, and Stop controls.
- Basic black Dynamic Island overlay.

Notes:
- This is an early prototype, not a full iOS Dynamic Island clone.
- Music metadata availability depends on the media app and Android media session.
- The current overlay does not yet include working play/pause/next buttons or album artwork.
- Android/HyperOS may stop a background service; continuous operation is not guaranteed in this prototype.
