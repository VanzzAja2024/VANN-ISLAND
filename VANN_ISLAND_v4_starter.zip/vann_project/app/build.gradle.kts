plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vann.island"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vann.island"
        minSdk = 26
        targetSdk = 32
        versionCode = 4
        versionName = "4.0"
    }
}
