package com.vann.island

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private var pill: TextView? = null
    private var testMode = false
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (testMode) return
            val title = intent?.getStringExtra("title") ?: "Music"
            val artist = intent?.getStringExtra("artist") ?: "Now Playing"
            pill?.text = "♫  $title\n     $artist"
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        testMode = intent?.getBooleanExtra("test_mode", false) ?: false
        if (pill == null) createPill() else {
            pill?.text = if (testMode) "♫  VANN TEST MODE\n     Preview active" else "♫  VANN ISLAND\n     Waiting for media"
        }
        return START_STICKY
    }

    private fun createPill() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val filter = IntentFilter("com.vann.island.MEDIA_UPDATE")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
        val prefs = getSharedPreferences("vann_settings", MODE_PRIVATE)
        val width = prefs.getInt("width", 270)
        val height = prefs.getInt("height", 56)
        val position = prefs.getInt("position", 24)
        pill = TextView(this).apply {
            text = if (testMode) "♫  VANN TEST MODE\n     Preview active" else "♫  VANN ISLAND\n     Waiting for media"
            setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
            setPadding(18, 8, 18, 8)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.BLACK); cornerRadius = height.toFloat()
                setStroke(1, 0xFF292929.toInt())
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(width.dp(), height.dp(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = (24 + position * 3).dp()
        wm.addView(pill, params)
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        try { pill?.let { wm.removeView(it) } } catch (_: Exception) {}
        pill = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
}
