package com.vann.island

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("vann_settings", MODE_PRIVATE) }
    private lateinit var preview: TextView
    private lateinit var widthValue: TextView
    private lateinit var heightValue: TextView
    private lateinit var positionValue: TextView
    private lateinit var status: TextView
    private var width = 270
    private var height = 56
    private var position = 24

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        width = prefs.getInt("width", 270)
        height = prefs.getInt("height", 56)
        position = prefs.getInt("position", 24)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
            setBackgroundColor(Color.rgb(8, 8, 10))
        }
        fun heading(value: String, size: Float): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(8))
        }
        fun section(value: String) { root.addView(heading(value, 17f)) }
        fun button(value: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = value; isAllCaps = false; setOnClickListener { action() } })
        }
        fun slider(label: String, max: Int, initial: Int, valueText: TextView, update: (Int) -> Unit) {
            root.addView(heading(label, 14f))
            root.addView(valueText.apply { textSize = 12f; setTextColor(0xFFBBBBBB.toInt()) })
            root.addView(SeekBar(this).apply {
                this.max = max; progress = initial
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) update(progress)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            })
        }

        root.addView(heading("VANN ISLAND", 28f))
        root.addView(heading("Dynamic Island Control Center · v4", 14f).apply { setTextColor(0xFFAAAAAA.toInt()) })
        section("LIVE PREVIEW")
        preview = TextView(this).apply {
            text = "♫   Music Preview\n      Artist · Ready"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE); textSize = 13f
            setBackgroundColor(Color.BLACK)
        }
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(18))
            setBackgroundColor(0xFF171719.toInt())
            addView(preview, LinearLayout.LayoutParams(dp(width), dp(height)))
        })
        widthValue = heading("", 12f); heightValue = heading("", 12f); positionValue = heading("", 12f)
        section("UKURAN & POSISI")
        slider("Lebar Island", 220, width - 180, widthValue) { width = 180 + it; saveAndPreview() }
        slider("Tinggi Island", 70, height - 30, heightValue) { height = 30 + it; saveAndPreview() }
        slider("Posisi dari atas", 100, position, positionValue) { position = it; saveAndPreview() }
        section("IZIN APLIKASI")
        button("IZIN TAMPIL DI ATAS APLIKASI") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("AKSES NOTIFIKASI & MUSIK") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        section("KONTROL ISLAND")
        button("TEST MODE · TAMPILKAN CONTOH") { startIsland(true) }
        button("START ISLAND") { startIsland(false) }
        button("STOP ISLAND") { stopService(Intent(this, IslandService::class.java)); Toast.makeText(this, "VANN ISLAND dihentikan", Toast.LENGTH_SHORT).show() }
        status = heading("Pengaturan tersimpan otomatis di perangkat.", 12f).apply { setTextColor(0xFFAAAAAA.toInt()) }
        root.addView(status)
        setContentView(root)
        updatePreview()
    }

    private fun startIsland(test: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin tampil di atas aplikasi dulu", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, IslandService::class.java).putExtra("test_mode", test)
        startService(intent)
        Toast.makeText(this, if (test) "Test Island aktif" else "VANN ISLAND aktif", Toast.LENGTH_SHORT).show()
    }

    private fun saveAndPreview() {
        prefs.edit().putInt("width", width).putInt("height", height).putInt("position", position).apply()
        updatePreview()
    }
    private fun updatePreview() {
        widthValue.text = "$width dp"; heightValue.text = "$height dp"; positionValue.text = "$position%"
        preview.layoutParams = preview.layoutParams?.apply { width = dp(width); height = dp(height) }
        preview.text = if (height < 48) "♫  Music" else "♫   Music Preview\n      Artist · Ready"
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
