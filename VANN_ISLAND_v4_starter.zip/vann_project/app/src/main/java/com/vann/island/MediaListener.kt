package com.vann.island

import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.content.ComponentName

class MediaListener : NotificationListenerService() {
    private var manager: MediaSessionManager? = null
    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: android.media.MediaMetadata?) {
            sendMedia(metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Music",
                metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: "Now Playing")
        }
    }
    override fun onListenerConnected() {
        super.onListenerConnected()
        manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        try {
            val sessions = manager?.getActiveSessions(ComponentName(this, MediaListener::class.java)).orEmpty()
            sessions.forEach { controller ->
                controller.registerCallback(callback)
                val metadata = controller.metadata
                sendMedia(metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Music",
                    metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: "Now Playing")
            }
        } catch (_: SecurityException) { }
    }
    override fun onNotificationPosted(sbn: android.service.notification.StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val artist = extras.getCharSequence("android.text")?.toString() ?: ""
        sendMedia(title, artist)
    }
    private fun sendMedia(title: String, artist: String) {
        sendBroadcast(android.content.Intent("com.vann.island.MEDIA_UPDATE")
            .setPackage(packageName).putExtra("title", title).putExtra("artist", artist))
    }
}
