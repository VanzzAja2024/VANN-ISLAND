# VANN ISLAND v5

Android Dynamic Island-style overlay for Redmi/Xiaomi and other Android devices.

Features in this build:
- Control Center with preview and sliders for width, height and vertical position.
- Manual Test, Start and Stop controls.
- NotificationListenerService to receive notifications from apps after the user enables Notification Access.
- Music metadata updates from active media sessions where supported by the media app.
- Flashlight toggle from the ⚡ control on the Island. Camera permission is requested for torch access.
- Local settings stored with Android SharedPreferences.

Important:
- This is a development build, not a finished iOS clone.
- Notification display depends on Android Notification Access and the notification content supplied by each app.
- Some apps hide message previews or use custom notifications, so their details may be limited.
- Media controls (play/pause/next) and album artwork are not yet implemented in this version.
- Xiaomi HyperOS may require enabling Autostart and setting battery restrictions to No restrictions. Start manually after reboot if HyperOS stops the service.
- The app does not send notification contents to a server.
