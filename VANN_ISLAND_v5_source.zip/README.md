# VANN ISLAND v8

Pembaruan:
- Ikon aplikasi VANN ISLAND.
- Animasi masuk Control Center saat aplikasi dibuka.
- Kapsul idle tetap kecil dan kosong, menyatu dengan area kamera.
- Saat notifikasi masuk, kapsul melebar dengan animasi dan kembali ke idle setelah 4,5 detik.
- Service tidak berhenti saat tidak ada notifikasi. Tekan STOP untuk menghentikan sepenuhnya.

Build menggunakan workflow GitHub Actions yang sama. Ubah nama ZIP pada perintah unzip menjadi `VANN_ISLAND_v8_source.zip`.
