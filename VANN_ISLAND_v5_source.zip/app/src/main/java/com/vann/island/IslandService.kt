package com.vann.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.animation.ValueAnimator
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ImageView

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var camera: CameraManager
    private var cameraId: String? = null
    private var root: LinearLayout? = null
    private var iconView: ImageView? = null
    private var currentPackage = ""
    private var titleView: TextView? = null
    private var bodyView: TextView? = null
    private var flashView: TextView? = null
    private var expanded = false
    private var testMode = false
    private var currentTitle = "VANN ISLAND"
    private var currentBody = "Menunggu notifikasi"
    private var currentIcon = "●"
    private var animator: ValueAnimator? = null
    private val handler = Handler(Looper.getMainLooper())
    private val collapseTask = Runnable { collapseToIdle() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.vann.island.MEDIA_UPDATE" -> {
                    if (testMode) return
                    currentIcon = intent.getStringExtra("icon") ?: "●"
                    currentTitle = intent.getStringExtra("title") ?: "Notifikasi"
                    currentBody = intent.getStringExtra("body") ?: intent.getStringExtra("source") ?: ""
                    currentPackage = intent.getStringExtra("source_package") ?: ""
                    renderContent()
                    showExpandedTemporarily()
                }
                "com.vann.island.NOTIFICATION_CLEARED" -> { /* Island tetap aktif dalam mode idle. */ }
                "com.vann.island.UPDATE_SETTINGS" -> updateLayout()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "vann_running")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("VANN ISLAND aktif")
            .setContentText("Island sedang berjalan").setOngoing(true).build()
        else Notification.Builder(this).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("VANN ISLAND aktif").build()
        startForeground(501, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        camera = getSystemService(CAMERA_SERVICE) as CameraManager
        try { cameraId = camera.cameraIdList.firstOrNull { camera.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } } catch (_: Exception) { }
        val filter = IntentFilter().apply {
            addAction("com.vann.island.MEDIA_UPDATE")
            addAction("com.vann.island.NOTIFICATION_CLEARED")
            addAction("com.vann.island.UPDATE_SETTINGS")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
        createIsland()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        testMode = intent?.getBooleanExtra("test_mode", false) ?: false
        if (testMode) {
            currentIcon = "♫"; currentTitle = "VANN TEST MODE"; currentBody = "Preview musik aktif"
            renderContent(); showExpandedTemporarily()
        } else {
            collapseToIdle()
        }
        return START_STICKY
    }

    private fun createIsland() {
        val prefs = getSharedPreferences("vann_settings", MODE_PRIVATE)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14.dp(), 5.dp(), 12.dp(), 5.dp())
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = 40.dp().toFloat()
                setStroke(1.dp(), 0xFF242428.toInt())
            }
            elevation = 12.dp().toFloat()
        }
        iconView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(0, 0, 8.dp(), 0)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        titleView = TextView(this).apply { textSize = 12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 1 }
        bodyView = TextView(this).apply { textSize = 10f; setTextColor(0xFFB8B8BE.toInt()); maxLines = 1 }
        texts.addView(titleView); texts.addView(bodyView)
        flashView = TextView(this).apply {
            text = "⚡"; textSize = 17f; setTextColor(0xFFFFD45A.toInt())
            gravity = Gravity.CENTER; setPadding(12.dp(), 0, 0, 0); setOnClickListener { toggleFlash() }
        }
        root?.addView(iconView, LinearLayout.LayoutParams(26.dp(), -1))
        root?.addView(texts, LinearLayout.LayoutParams(0, -1, 1f))
        root?.addView(flashView)
        root?.setOnClickListener {
            if (expanded) collapseToIdle() else showExpandedTemporarily()
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(idleWidth().dp(), idleHeight().dp(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = topOffset().dp()
        try { wm.addView(root, params) } catch (_: Exception) { }
        renderContent()
        setIdleVisibility()
    }

    private fun idleWidth() = 116
    private fun idleHeight() = 36
    // Nilai slider lama 18 dipetakan dekat tepi atas, sejajar dengan kamera depan Redmi 13C.
    private fun topOffset(): Int {
        val position = getSharedPreferences("vann_settings", MODE_PRIVATE).getInt("position", 18)
        return (position - 14).coerceIn(0, 80)
    }

    private fun renderContent() {
        titleView?.text = currentTitle
        bodyView?.text = currentBody
        if (currentPackage.isNotBlank()) {
            try {
                iconView?.setImageDrawable(packageManager.getApplicationIcon(currentPackage))
            } catch (_: Exception) {
                iconView?.setImageResource(android.R.drawable.ic_dialog_info)
            }
        } else {
            iconView?.setImageResource(android.R.drawable.ic_media_play)
        }
    }

    private fun setIdleVisibility() {
        val visibility = if (expanded) View.VISIBLE else View.GONE
        iconView?.visibility = visibility
        titleView?.visibility = visibility
        bodyView?.visibility = visibility
        flashView?.visibility = visibility
    }

    private fun showExpandedTemporarily() {
        handler.removeCallbacks(collapseTask)
        expanded = true
        setIdleVisibility()
        animateSize((getSharedPreferences("vann_settings", MODE_PRIVATE).getInt("width", 300) + 30).coerceAtMost(360),
            getSharedPreferences("vann_settings", MODE_PRIVATE).getInt("height", 58) + 22)
        root?.animate()?.alpha(1f)?.scaleX(1f)?.scaleY(1f)?.setDuration(220)?.setInterpolator(DecelerateInterpolator())?.start()
        handler.postDelayed(collapseTask, 4500)
    }

    private fun collapseToIdle() {
        handler.removeCallbacks(collapseTask)
        expanded = false
        setIdleVisibility()
        animateSize(idleWidth(), idleHeight())
        root?.animate()?.alpha(1f)?.scaleX(1f)?.scaleY(1f)?.setDuration(260)?.setInterpolator(DecelerateInterpolator())?.start()
    }

    private fun animateSize(targetWidth: Int, targetHeight: Int) {
        val v = root ?: return
        val params = v.layoutParams as? WindowManager.LayoutParams ?: return
        animator?.cancel()
        val startW = params.width / resources.displayMetrics.density
        val startH = params.height / resources.displayMetrics.density
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 260
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                params.width = (startW + (targetWidth - startW) * f).toInt().dp()
                params.height = (startH + (targetHeight - startH) * f).toInt().dp()
                try { wm.updateViewLayout(v, params) } catch (_: Exception) { }
            }
            start()
        }
    }

    private fun updateLayout() {
        val v = root ?: return
        val p = v.layoutParams as? WindowManager.LayoutParams ?: return
        p.y = topOffset().dp()
        try { wm.updateViewLayout(v, p) } catch (_: Exception) { }
        if (expanded) showExpandedTemporarily() else collapseToIdle()
    }

    private fun toggleFlash() {
        val id = cameraId ?: return
        try {
            val prefs = getSharedPreferences("vann_settings", MODE_PRIVATE)
            val on = prefs.getBoolean("flash_on", false)
            camera.setTorchMode(id, !on)
            prefs.edit().putBoolean("flash_on", !on).apply()
            flashView?.setTextColor(if (!on) 0xFF27D66B.toInt() else 0xFFFFD45A.toInt())
        } catch (_: SecurityException) { } catch (_: Exception) { }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("vann_running", "VANN Island", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        animator?.cancel()
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        try { root?.let { wm.removeView(it) } } catch (_: Exception) { }
        try { cameraId?.let { camera.setTorchMode(it, false) } } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
}
