package com.vann.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var camera: CameraManager
    private var cameraId: String? = null
    private var root: LinearLayout? = null
    private var titleView: TextView? = null
    private var bodyView: TextView? = null
    private var flashView: TextView? = null
    private var expanded = false
    private var testMode = false
    private var currentTitle = "VANN ISLAND"
    private var currentBody = "Menunggu notifikasi"
    private var currentIcon = "●"
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.vann.island.MEDIA_UPDATE" -> {
                    if (testMode) return
                    currentIcon = intent.getStringExtra("icon") ?: "●"
                    currentTitle = intent.getStringExtra("title") ?: "Notifikasi"
                    currentBody = intent.getStringExtra("body") ?: intent.getStringExtra("source") ?: ""
                    renderContent()
                    expandBriefly()
                }
                "com.vann.island.NOTIFICATION_CLEARED" -> { }
                "com.vann.island.UPDATE_SETTINGS" -> updateLayout()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, "vann_running")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("VANN ISLAND aktif")
            .setContentText("Island sedang berjalan").setOngoing(true).build()
            else Notification.Builder(this).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("VANN ISLAND aktif").build()
        startForeground(501, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        camera = getSystemService(CAMERA_SERVICE) as CameraManager
        try { cameraId = camera.cameraIdList.firstOrNull { camera.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } } catch (_: Exception) {}
        val filter = IntentFilter().apply { addAction("com.vann.island.MEDIA_UPDATE"); addAction("com.vann.island.NOTIFICATION_CLEARED"); addAction("com.vann.island.UPDATE_SETTINGS") }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
        createIsland()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        testMode = intent?.getBooleanExtra("test_mode", false) ?: false
        if (testMode) { currentIcon = "♫"; currentTitle = "VANN TEST MODE"; currentBody = "Preview musik aktif"; renderContent(); expandBriefly() }
        return START_STICKY
    }

    private fun createIsland() {
        val prefs = getSharedPreferences("vann_settings", MODE_PRIVATE)
        val width = prefs.getInt("width", 300)
        val height = prefs.getInt("height", 58)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(18.dp(), 7.dp(), 14.dp(), 7.dp())
            background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = 40.dp().toFloat(); setStroke(1.dp(), 0xFF242428.toInt()) }
            elevation = 12.dp().toFloat()
        }
        val icon = TextView(this).apply { text = currentIcon; textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0,0,10.dp(),0) }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        titleView = TextView(this).apply { textSize = 12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 1 }
        bodyView = TextView(this).apply { textSize = 10f; setTextColor(0xFFB8B8BE.toInt()); maxLines = 1 }
        texts.addView(titleView); texts.addView(bodyView)
        flashView = TextView(this).apply { text = "⚡"; textSize = 17f; setTextColor(0xFFFFD45A.toInt()); gravity = Gravity.CENTER; setPadding(12.dp(),0,0,0); setOnClickListener { toggleFlash() } }
        root?.addView(icon, LinearLayout.LayoutParams(26.dp(), -1)); root?.addView(texts, LinearLayout.LayoutParams(0, -1, 1f)); root?.addView(flashView)
        root?.setOnClickListener { expanded = !expanded; updateLayout() }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(width.dp(), height.dp(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = (24 + prefs.getInt("position", 18) * 2).dp()
        try { wm.addView(root, params) } catch (_: Exception) { }
        renderContent()
    }

    private fun renderContent() { titleView?.text = currentTitle; bodyView?.text = currentBody }
    private fun expandBriefly() { expanded = true; updateLayout() }
    private fun updateLayout() {
        val v = root ?: return
        val p = v.layoutParams as? WindowManager.LayoutParams ?: return
        val prefs = getSharedPreferences("vann_settings", MODE_PRIVATE)
        p.width = (if (expanded) (prefs.getInt("width", 300) + 30).coerceAtMost(360) else prefs.getInt("width", 300)).dp()
        p.height = (if (expanded) prefs.getInt("height", 58) + 22 else prefs.getInt("height", 58)).dp()
        p.y = (24 + prefs.getInt("position", 18) * 2).dp()
        try { wm.updateViewLayout(v, p) } catch (_: Exception) { }
    }
    private fun toggleFlash() {
        val id = cameraId ?: return
        try {
            val on = getSharedPreferences("vann_settings", MODE_PRIVATE).getBoolean("flash_on", false)
            camera.setTorchMode(id, !on)
            getSharedPreferences("vann_settings", MODE_PRIVATE).edit().putBoolean("flash_on", !on).apply()
            flashView?.setTextColor(if (!on) 0xFF27D66B.toInt() else 0xFFFFD45A.toInt())
        } catch (_: SecurityException) { }
        catch (_: Exception) { }
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("vann_running", "VANN Island", NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        try { root?.let { wm.removeView(it) } } catch (_: Exception) { }
        try { cameraId?.let { camera.setTorchMode(it, false) } } catch (_: Exception) { }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
}
