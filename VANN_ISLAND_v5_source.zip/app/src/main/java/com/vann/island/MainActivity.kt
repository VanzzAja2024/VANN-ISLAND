package com.vann.island

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("vann_settings", MODE_PRIVATE) }
    private lateinit var preview: TextView
    private lateinit var widthValue: TextView
    private lateinit var heightValue: TextView
    private lateinit var positionValue: TextView
    private var width = 300
    private var height = 58
    private var position = 18

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        width = prefs.getInt("width", 300); height = prefs.getInt("height", 58); position = prefs.getInt("position", 18)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(24), dp(20), dp(28)); setBackgroundColor(Color.rgb(8,8,10)) }
        val scroll = ScrollView(this); scroll.addView(root)
        fun heading(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0,dp(8),0,dp(8)) }
        fun section(s: String) { root.addView(heading(s,17f)) }
        fun button(s: String, action: () -> Unit) { root.addView(Button(this).apply { text=s; isAllCaps=false; setOnClickListener { action() } }) }
        root.addView(heading("VANN ISLAND",29f)); root.addView(heading("Dynamic Island Control Center · v5",14f,0xFFAAAAAA.toInt()))
        section("LIVE PREVIEW")
        preview = TextView(this).apply { text="♫   Music Preview
      Artist · Ready"; gravity=Gravity.CENTER; setTextColor(Color.WHITE); textSize=13f; background=android.graphics.drawable.GradientDrawable().apply { setColor(Color.BLACK); cornerRadius=dp(35).toFloat() } }
        root.addView(LinearLayout(this).apply { gravity=Gravity.CENTER; setPadding(0,dp(14),0,dp(14)); addView(preview,LinearLayout.LayoutParams(dp(width),dp(height))) })
        widthValue=heading("",12f,0xFFBBBBBB.toInt()); heightValue=heading("",12f,0xFFBBBBBB.toInt()); positionValue=heading("",12f,0xFFBBBBBB.toInt())
        section("UKURAN & POSISI")
        slider(root,"Lebar Island",160,width-200,widthValue) { width=200+it; save() }
        slider(root,"Tinggi Island",70,height-40,heightValue) { height=40+it; save() }
        slider(root,"Posisi dari atas",100,position,positionValue) { position=it; save() }
        section("IZIN APLIKASI")
        button("IZIN TAMPIL DI ATAS APLIKASI") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        button("AKSES NOTIFIKASI SEMUA APLIKASI") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        button("IZIN KAMERA UNTUK SENTER") { if (Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.CAMERA),77) else Toast.makeText(this,"Izin kamera sudah tersedia",Toast.LENGTH_SHORT).show() }
        section("KONTROL ISLAND")
        button("TEST MODE · TAMPILKAN CONTOH") { startIsland(true) }
        button("START ISLAND") { startIsland(false) }
        button("STOP ISLAND") { stopService(Intent(this,IslandService::class.java)); Toast.makeText(this,"VANN ISLAND dihentikan",Toast.LENGTH_SHORT).show() }
        root.addView(heading("Notifikasi aplikasi lain akan tampil setelah Notification Access diaktifkan. Ketuk ikon ⚡ di Island untuk senter. Pengaturan tersimpan otomatis.",12f,0xFFAAAAAA.toInt()))
        setContentView(scroll); updatePreview()
    }
    private fun slider(root: LinearLayout,label:String,max:Int,initial:Int,valueText:TextView,update:(Int)->Unit) {
        root.addView(TextView(this).apply { text=label; textSize=14f; setTextColor(Color.WHITE) }); root.addView(valueText)
        root.addView(SeekBar(this).apply { this.max=max; progress=initial.coerceIn(0,max); setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean){ if(fromUser) update(p) }
            override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){}
        }) })
    }
    private fun startIsland(test:Boolean) {
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this,"Aktifkan izin overlay dulu",Toast.LENGTH_LONG).show(); startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))); return }
        val i=Intent(this,IslandService::class.java).putExtra("test_mode",test)
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
        Toast.makeText(this,if(test) "Test Island aktif" else "VANN ISLAND aktif",Toast.LENGTH_SHORT).show()
    }
    private fun save() { prefs.edit().putInt("width",width).putInt("height",height).putInt("position",position).apply(); updatePreview(); sendBroadcast(Intent("com.vann.island.UPDATE_SETTINGS").setPackage(packageName)) }
    private fun updatePreview() { widthValue.text="$width dp"; heightValue.text="$height dp"; positionValue.text="$position%"; preview.layoutParams=preview.layoutParams?.apply { width=dp(width); height=dp(height) }; preview.text=if(height<52) "♫  Music" else "♫   Music Preview
      Artist · Ready" }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
