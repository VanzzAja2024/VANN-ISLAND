package com.vann.island

import android.content.ComponentName
import android.content.Intent
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MediaListener : NotificationListenerService() {
    private var manager: MediaSessionManager? = null
    private val controllers = mutableSetOf<MediaController>()
    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: android.media.MediaMetadata?) {
            sendUpdate("♫", metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Sedang diputar",
                metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: "Musik", "media")
        }
        override fun onPlaybackStateChanged(state: android.media.session.PlaybackState?) {
            val playing = state?.state == android.media.session.PlaybackState.STATE_PLAYING
            sendUpdate(if (playing) "♫" else "Ⅱ", "Pemutar musik", if (playing) "Sedang diputar" else "Dijeda", "media")
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        refreshSessions()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString()?.takeIf { it.isNotBlank() } ?: return
        val body = extras.getCharSequence("android.bigText")?.toString()
            ?: extras.getCharSequence("android.text")?.toString().orEmpty()
        val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() }
            catch (_: Exception) { sbn.packageName.substringAfterLast('.') }
        sendUpdate("●", title, body, appName)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) { sendBroadcast(Intent("com.vann.island.NOTIFICATION_CLEARED").setPackage(packageName)) }

    private fun refreshSessions() {
        try {
            controllers.forEach { it.unregisterCallback(callback) }
            controllers.clear()
            val active = manager?.getActiveSessions(ComponentName(this, MediaListener::class.java)).orEmpty()
            active.forEach { controller ->
                controllers.add(controller)
                controller.registerCallback(callback)
                val m = controller.metadata
                if (m != null) sendUpdate("♫", m.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "Sedang diputar",
                    m.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: "Musik", "media")
            }
        } catch (_: SecurityException) { }
    }

    private fun sendUpdate(icon: String, title: String, body: String, source: String) {
        sendBroadcast(Intent("com.vann.island.MEDIA_UPDATE").setPackage(packageName)
            .putExtra("icon", icon).putExtra("title", title).putExtra("body", body).putExtra("source", source))
    }
}
